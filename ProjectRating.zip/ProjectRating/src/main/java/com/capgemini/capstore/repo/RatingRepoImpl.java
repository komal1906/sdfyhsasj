package com.capgemini.capstore.repo;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


@Repository("repo")
public class RatingRepoImpl implements RatingRepo{

	@PersistenceContext
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public void avgRating(long prod_id) {
		
		List<Long> rate1 = entityManager.createQuery("SELECT pf FROM product_feedback pf WHERE pf.prod_id  =:prod_id").setParameter("prod_id", prod_id).getResultList();
		long sum=0;
		long avg;
		
		for(long i:rate1)
		{
			long rate = (long) entityManager.createQuery("SELECT f FROM feedback f WHERE f.feedback_id  =:fid").setParameter("fid", i).getSingleResult();
			sum+=rate;
		}
		avg=sum/rate1.size();
		
		Query avgrate= (Query) entityManager.createQuery("select r.rating from product r where r.prod_id =: pid").setParameter("pid", prod_id).getSingleResult();
		entityManager.setProperty("rating",avg);
		entityManager.merge(avgrate);
		return ;
	}
}
