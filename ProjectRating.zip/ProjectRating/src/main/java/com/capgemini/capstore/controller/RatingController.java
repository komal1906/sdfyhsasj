package com.capgemini.capstore.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.capstore.beans.Feedback;
import com.capgemini.capstore.services.RatingServices;



@Controller
public class RatingController {

	@Autowired
	RatingServices ser;
	
	@RequestMapping(value="/{prodid}")
	public void avgRating(@PathVariable long prodid )
	{
		ser.avgRating(prodid);
		
		return ;

	}
	
	
}
