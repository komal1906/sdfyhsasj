package com.capgemini.capstore.services;

public interface RatingServices
{
	public void avgRating(long prodid);
}
