package com.capgemini.capstore.repo;

public interface RatingRepo
{
	public void avgRating(long prodid);
}

