package FeatureConference;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.PageFactoryConference;

public class StepDefConference {
	
	private WebDriver driver;
	private PageFactoryConference conf;

@Given("^User is on Conference Registartion page$")
public void user_is_on_Conference_Registartion_page() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\ChromePath\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	conf = new PageFactoryConference(driver);
	driver.get("file://ndafile/GLC-G102/BDD%20MPT%20HTML%20files/Set%20B/ConferenceRegistartion.html#");
	
}

@Then("^Check the title of the page$")
public void check_the_title_of_the_page() throws Throwable {
	String title=driver.getTitle();
	if(title.contentEquals("Conference Registartion"))
		System.out.println("****** Title Matched");
	else 
		System.out.println("****** Title NOT Matched");
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	driver.close();
}

@When("^user leaves first Name blank and clicks the link$")
public void user_leaves_first_Name_blank_and_clicks_the_link() throws Throwable {
   conf.setPfFirstName("");
   Thread.sleep(1000);
   conf.setPfLink();
   Thread.sleep(1000);
}

@Then("^display alert msg$")
public void display_alert_msg() throws Throwable {
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);
    driver.close();
}

@When("^user leaves last Name blank and clicks the link$")
public void user_leaves_last_Name_blank_and_clicks_the_link() throws Throwable {
    conf.setPfFirstName("Komal");
    conf.setPfLastName("");
    conf.setPfLink();
    
}

@When("^user enters incorrect email format and clicks the link$")
public void user_enters_incorrect_email_format_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal.@.");
    Thread.sleep(500);
    conf.setPfLink();
}

@When("^user leaves ContactNo empty and clicks the link$")
public void user_leaves_ContactNo_empty_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("");
    conf.setPfLink();
}

@When("^user enters incorrect ContactNo format and clicks the link$")
public void user_enters_incorrect_ContactNo_format_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("1234567890");
    conf.setPfLink();
}

@When("^user does not select no\\. of people and clicks the link$")
public void user_does_not_select_no_of_people_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("7234567890");
    Thread.sleep(500);
    conf.setPfnoPeople("");
    Thread.sleep(500);
    conf.setPfLink();
}

@When("^user leaves Building name empty and clicks the link$")
public void user_leaves_Building_name_empty_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("7234567890");
    Thread.sleep(500);
    conf.setPfnoPeople("4");
    Thread.sleep(500);
    conf.setPfBuildingno("");
    Thread.sleep(500);
    conf.setPfLink();
}

@When("^user leaves Area name empty and clicks the link$")
public void user_leaves_Area_name_empty_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("7234567890");
    Thread.sleep(500);
    conf.setPfnoPeople("4");
    Thread.sleep(500);
    conf.setPfBuildingno("NH2/10");
    Thread.sleep(500);
    conf.setPfArea("");
    Thread.sleep(500);
    conf.setPfLink();
}

@When("^user does not select city and clicks the link$")
public void user_does_not_select_city_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("7234567890");
    Thread.sleep(500);
    conf.setPfnoPeople("4");
    Thread.sleep(500);
    conf.setPfBuildingno("NH2/10");
    Thread.sleep(500);
    conf.setPfArea("Mathura");
    Thread.sleep(500);
    conf.setPfCity("");
    Thread.sleep(500);
    conf.setPfLink();
}

@When("^user does not select state and clicks the link$")
public void user_does_not_select_state_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("7234567890");
    Thread.sleep(500);
    conf.setPfnoPeople("4");
    Thread.sleep(500);
    conf.setPfBuildingno("NH2/10");
    Thread.sleep(500);
    conf.setPfArea("Mathura");
    Thread.sleep(500);
    conf.setPfCity("Pune");
    Thread.sleep(500);
    conf.setPfState("");
    Thread.sleep(500);
    conf.setPfLink();
}

@When("^user does not select membership and clicks the link$")
public void user_does_not_select_membership_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    conf.setPfPhone("7234567890");
    Thread.sleep(500);
    conf.setPfnoPeople("4");
    Thread.sleep(500);
    conf.setPfBuildingno("NH2/10");
    Thread.sleep(500);
    conf.setPfArea("Mathura");
    Thread.sleep(500);
    conf.setPfCity("Pune");
    Thread.sleep(500);
    conf.setPfState("Maharashtra");
    Thread.sleep(500);
    conf.setPfLink();
}

@When("^enters all the valid data and clicks the link$")
public void enters_all_the_valid_data_and_clicks_the_link() throws Throwable {
	conf.setPfFirstName("Komal");
	Thread.sleep(500);
    conf.setPfLastName("Agrawal");
    Thread.sleep(500);
    conf.setPfEmail("komal@gmail.com");
    Thread.sleep(500);
    conf.setPfPhone("7234567890");
    Thread.sleep(500);
    conf.setPfnoPeople("4");
    Thread.sleep(500);
    conf.setPfBuildingno("NH2/10");
    Thread.sleep(500);
    conf.setPfArea("Mathura");
    Thread.sleep(500);
    conf.setPfCity("Pune");
    Thread.sleep(500);
    conf.setPfState("Maharashtra");
    Thread.sleep(500);
    conf.setPfMember();
    Thread.sleep(500);
    conf.setPfLink();
    
}

@When("^display alert succesful msg$")
public void display_alert_succesful_msg() throws Throwable {
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);

}

@Then("^navigate to PersonalDetail page$")
public void navigate_to_PersonalDetail_page() throws Throwable {
	driver.navigate().to("file://ndafile/GLC-G102/BDD%20MPT%20HTML%20files/Set%20B/PaymentDetails.html");
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	driver.close();
}

@Given("^User is on Personal Detail page$")
public void user_is_on_Personal_Detail_page() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\ChromePath\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	conf = new PageFactoryConference(driver);
	driver.get("file://ndafile/GLC-G102/BDD%20MPT%20HTML%20files/Set%20B/PaymentDetails.html");
	
}
@Then("^Check the title of the personal page$")
public void check_the_title_of_the_personal_page() throws Throwable {
	String title=driver.getTitle();
	if(title.contentEquals("Payment Details"))
		System.out.println("****** Title Matched");
	else 
		System.out.println("****** Title NOT Matched");
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	driver.close();
}

@When("^user leaves cardholderName empty and clicks the button$")
public void user_leaves_cardholderName_empty_and_clicks_the_button() throws Throwable {
    conf.setPfCardHolder("");
    conf.setPfButton();
}

@Then("^display alert msg of details$")
public void display_alert_msg_of_details() throws Throwable {
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);
    driver.close();
}

@When("^user leaves debitCardNumber empty and clicks the button$")
public void user_leaves_debitCardNumber_empty_and_clicks_the_button() throws Throwable {
	conf.setPfCardHolder("Komal Agrawal");
	Thread.sleep(500);
	conf.setPfCardNumber("");
	Thread.sleep(500);
    conf.setPfButton();
}

@When("^user leaves cvv empty and clicks the button$")
public void user_leaves_cvv_empty_and_clicks_the_button() throws Throwable {
	conf.setPfCardHolder("Komal Agrawal");
	Thread.sleep(500);
	conf.setPfCardNumber("789456123078");
	Thread.sleep(500);
	conf.setPfCvv("");
	Thread.sleep(500);
    conf.setPfButton();
}

@When("^user leaves exp month empty and clicks the button$")
public void user_leaves_exp_month_empty_and_clicks_the_button() throws Throwable {
	conf.setPfCardHolder("Komal Agrawal");
	Thread.sleep(500);
	conf.setPfCardNumber("789456123078");
	Thread.sleep(500);
	conf.setPfCvv("789");
	Thread.sleep(500);
	conf.setPfMonth("");
	Thread.sleep(500);
    conf.setPfButton();
}

@When("^user leaves exp year empty and clicks the button$")
public void user_leaves_exp_year_empty_and_clicks_the_button() throws Throwable {
	conf.setPfCardHolder("Komal Agrawal");
	Thread.sleep(500);
	conf.setPfCardNumber("789456123078");
	Thread.sleep(500);
	conf.setPfCvv("789");
	Thread.sleep(500);
	conf.setPfMonth("4");
	Thread.sleep(500);
	conf.setPfYear("");
	Thread.sleep(500);
    conf.setPfButton();
}
@When("^enters all the valid Personal data and clicks the button$")
public void enters_all_the_valid_Personal_data_and_clicks_the_button() throws Throwable {
	conf.setPfCardHolder("Komal Agrawal");
	Thread.sleep(500);
	conf.setPfCardNumber("789456123078");
	Thread.sleep(500);
	conf.setPfCvv("789");
	Thread.sleep(500);
	conf.setPfMonth("4");
	Thread.sleep(500);
	conf.setPfYear("2022");
	Thread.sleep(500);
    conf.setPfButton();
}

}

