package pageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


//This page factory is used to locate the locaters of all data
public class PageFactoryConference {
WebDriver driver;

	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement pfFirstName;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement pfLastName;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement pfEmail;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement pfPhone;
	
	@FindBy(name="size")
	@CacheLookup
	WebElement pfnoPeople;
	
	@FindBy(id="txtAddress1")
	@CacheLookup
	WebElement pfBuildingno;
	
	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement pfArea;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement pfCity;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement pfState;
	
	@FindBy(css="input[value='member']")
	@CacheLookup
	WebElement pfMember;
	
	@FindBy(css="input[value='non-member']")
	@CacheLookup
	WebElement pfNonMember;

	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement pfCardHolder;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement pfCardNumber;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement pfCvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement pfMonth;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement pfYear;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement pfButton;
	
	@FindBy(linkText="Next")
	@CacheLookup
	WebElement pfLink;
	
public PageFactoryConference(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}



public WebElement getPfFirstName() {
	return pfFirstName;
}

public void setPfFirstName(String sFirstName) {
	pfFirstName.sendKeys(sFirstName);
}

public WebElement getPfLastName() {
	return pfLastName;
}

public void setPfLastName(String sLastName) {
	pfLastName.sendKeys(sLastName);
}

public WebElement getPfEmail() {
	return pfEmail;
}

public void setPfEmail(String sEmail) {
	pfEmail.sendKeys(sEmail);
}

public WebElement getPfPhone() {
	return pfPhone;
}

public void setPfPhone(String sPhone) {
	pfPhone.sendKeys(sPhone);
}

public WebElement getPfnoPeople() {
	return pfnoPeople;
}

public void setPfnoPeople(String snoPeople) {
	pfnoPeople.sendKeys(snoPeople);
}

public WebElement getPfBuildingno() {
	return pfBuildingno;
}

public void setPfBuildingno(String sBuildingno) {
	pfBuildingno.sendKeys(sBuildingno);;
}

public WebElement getPfArea() {
	return pfArea;
}

public void setPfArea(String sArea) {
	pfArea.sendKeys(sArea);
}

public WebElement getPfCity() {
	return pfCity;
}

public void setPfCity(String sCity) {
	pfCity.sendKeys(sCity);
}

public WebElement getPfState() {
	return pfState;
}

public void setPfState(String sState) {
	pfState.sendKeys(sState);
}

public WebElement getPfMember() {
	return pfMember;
}

public void setPfMember() {
	pfMember.click();
}

public WebElement getPfNonMember() {
	return pfNonMember;
}

public void setPfNonMember() {
	pfNonMember.click();
}



public WebElement getPfCardHolder() {
	return pfCardHolder;
}

public void setPfCardHolder(String sCardHolder) {
	pfCardHolder.sendKeys(sCardHolder);
}

public WebElement getPfCardNumber() {
	return pfCardNumber;
}

public void setPfCardNumber(String sCardNumber) {
	pfCardNumber.sendKeys(sCardNumber);
}

public WebElement getPfCvv() {
	return pfCvv;
}

public void setPfCvv(String sCvv) {
	pfCvv.sendKeys(sCvv);
}

public WebElement getPfMonth() {
	return pfMonth;
}

public void setPfMonth(String sMonth) {
	pfMonth.sendKeys(sMonth);
}

public WebElement getPfYear() {
	return pfYear;
}

public void setPfYear(String sYear) {
	pfYear.sendKeys(sYear);
}

public WebElement getPfButton() {
	return pfButton;
}

public void setPfButton() {
	pfButton.click();
}

public WebElement getPfLink() {
	return pfLink;
}

public void setPfLink() {
	pfLink.click();
}
}
