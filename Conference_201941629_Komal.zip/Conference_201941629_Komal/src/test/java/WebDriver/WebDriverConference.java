package WebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import pageBean.PageFactoryConference;

public class WebDriverConference
{static WebDriver driver;
public static void main(String args[]) throws InterruptedException
{
	
	System.setProperty("webdriver.chrome.driver","D:\\ChromePath\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file://ndafile/GLC-G102/BDD%20MPT%20HTML%20files/Set%20B/ConferenceRegistartion.html#");
	//Empty first name
	driver.findElement(By.id("txtFirstName")).sendKeys("");
	callAlert();
	
	//Empty last name
	driver.findElement(By.id("txtFirstName")).sendKeys("Komal");
	driver.findElement(By.id("txtLastName")).sendKeys("");
	callAlert();
	
	//Empty Email
	driver.findElement(By.id("txtLastName")).sendKeys("Agrawal");
	driver.findElement(By.id("txtEmail")).sendKeys("");
	callAlert();

	//Wrong email format
	driver.findElement(By.id("txtEmail")).sendKeys("komal@.com");
	callAlert();
	
	//Correct email format
	//Empty contact no
	driver.findElement(By.id("txtEmail")).clear();
	driver.findElement(By.id("txtEmail")).sendKeys("komal@gmail.com");
	driver.findElement(By.id("txtPhone")).sendKeys("");
	callAlert();
	
	//Invalid contact no format
	driver.findElement(By.id("txtPhone")).sendKeys("18940");
	callAlert();
	
	//Valid contact no
	driver.findElement(By.id("txtPhone")).clear();
	driver.findElement(By.id("txtPhone")).sendKeys("7894561230");
	callAlert();
	
	//no of people not selected
	driver.findElement(By.name("size")).sendKeys("");
	callAlert();
	
	//Building number is empty
	driver.findElement(By.name("size")).sendKeys("4");
	driver.findElement(By.id("txtAddress1")).sendKeys("");
	callAlert();
	
	//Area Name is empty
	driver.findElement(By.id("txtAddress1")).sendKeys("NH2/10");
	driver.findElement(By.id("txtAddress2")).sendKeys("");
	callAlert();
	
	//city is not selected
	driver.findElement(By.id("txtAddress2")).sendKeys("Shri Nagar");
	driver.findElement(By.name("city")).sendKeys("");
	callAlert();

	//state is not selected
	Select drpCity=new Select(driver.findElement(By.name("city")));
	drpCity.selectByIndex(1);
	driver.findElement(By.name("state")).sendKeys("");
	callAlert();
	
	//All the data is entered
	Select drpState=new Select(driver.findElement(By.name("state")));
	drpState.selectByIndex(1);
	driver.findElement(By.cssSelector("input[value='non-member']")).click();
	driver.findElement(By.linkText("Next")).click();
	String alertmes=driver.switchTo().alert().getText();
	System.out.println(alertmes);
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	Thread.sleep(2000);
	
	//navigate to next personal detail page
	driver.navigate().to("file://ndafile/GLC-G102/BDD%20MPT%20HTML%20files/Set%20B/PaymentDetails.html");
	
	//empty card holder name
	driver.findElement(By.id("txtCardholderName")).sendKeys("");
	callAlert1();
	
	//empty debit card number
	driver.findElement(By.id("txtCardholderName")).sendKeys("Komal Agrawal");
	driver.findElement(By.id("txtDebit")).sendKeys("");
	callAlert1();
	
	//empty cvv number
	driver.findElement(By.id("txtDebit")).sendKeys("123456789012");
	driver.findElement(By.id("txtCvv")).sendKeys("");
	callAlert1();
	
	//empty expiration month
	driver.findElement(By.id("txtCvv")).sendKeys("123");
	driver.findElement(By.id("txtMonth")).sendKeys("");
	callAlert1();
	
	//empty expiration year 
	driver.findElement(By.id("txtMonth")).sendKeys("10");
	driver.findElement(By.id("txtYear")).sendKeys("");
	callAlert1();
	
	//all the valid data entered in personal details page form
	driver.findElement(By.id("txtYear")).sendKeys("2020");
	driver.findElement(By.id("btnPayment")).click();
	String alertmes1=driver.switchTo().alert().getText();
	System.out.println(alertmes1);
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
	Thread.sleep(1000);
	
	driver.quit();// to close the browser
	
}
// this callAlert method is used to click the link "next" and display the alert boxes
public static void callAlert() throws InterruptedException
{
		driver.findElement(By.linkText("Next")).click();
		String alertmes=driver.switchTo().alert().getText();
		System.out.println(alertmes);
		Thread.sleep(500);
		driver.switchTo().alert().accept();
		Thread.sleep(500);
			
}
//this callAlert1 method is used to click the button "Make payment" and display the alert boxes
public static void callAlert1() throws InterruptedException
{
		driver.findElement(By.id("btnPayment")).click();
		String alertmes=driver.switchTo().alert().getText();
		System.out.println(alertmes);
		Thread.sleep(500);
		driver.switchTo().alert().accept();
		Thread.sleep(500);
			
}
}
